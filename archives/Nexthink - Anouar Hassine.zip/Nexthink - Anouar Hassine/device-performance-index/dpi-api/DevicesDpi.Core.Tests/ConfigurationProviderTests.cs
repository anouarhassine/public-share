﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using NSubstitute;

using DevicesDpi.Core.Interfaces;
using DevicesDpi.Core.Services;

namespace DevicesDpi.Core.Tests
{
    [TestFixture]
    public class ConfigurationProviderTests
    {
        [Test]
        public void GivenAListOfValuesCalculatesExactPercentiles()
        {
            var values = new List<int>()
            {
                193, 1, 26, 70, 107, 115, 118, 166, 71, 11, 111, 64, 157, 51, 136, 168, 8, 163,
                51, 48, 37, 60, 94, 11, 104, 122, 171, 187, 143, 24, 129, 31, 46, 88, 24, 108,
                19, 119, 80, 42, 32, 74, 113, 142, 50, 99, 82, 157, 85, 24, 170, 187, 133, 64,
                64, 186, 37, 43, 14, 102, 34, 134, 122, 77, 145, 76, 195, 93, 190, 109, 82, 200,
                153, 152, 79, 43, 157, 19, 147, 162, 168, 84, 4, 6, 74, 66, 19, 29, 199, 150, 15,
                192, 34, 62, 117, 192, 118, 146, 138, 22
            };

            var devicesRepositoryMock = Substitute.For<IDeviceRepository>();

            var dpiConfigurationProvider = new ConfigurationProvider(devicesRepositoryMock, null);
            var metricConfiguration = dpiConfigurationProvider.GetMetricConfiguration(values, false, true);

            Assert.AreEqual(4, metricConfiguration.Min);
            Assert.AreEqual(195, metricConfiguration.Max);
            Assert.IsFalse(metricConfiguration.Flip);
        }
    }
}
