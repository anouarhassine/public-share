using System;
using System.Collections.Generic;
using NUnit.Framework;
using DevicesDpi.Core.Entities;
using DevicesDpi.Core.Interfaces;
using DevicesDpi.Core.Services;

namespace DevicesDpi.Core.Tests
{
    public class DpiCalculatorTests
    {
        private DpiConfiguration _dpiConfiguration;
        private IDpiCalculator _dpiCalculator;

        [OneTimeSetUp]
        public void Setup()
        {
            _dpiConfiguration = new DpiConfiguration
            {
                BootSpeedConfig = new MetricConfiguration<int>() { Min = 123, Max = 255000 },
                BsodCountConfig = new MetricConfiguration<int>() { Min = 0, Max = 14 },
                CpuUsageConfig = new MetricConfiguration<decimal>() { Min = 0.001M, Max = 0.99M },
                HardResetCountConfig = new MetricConfiguration<int>() { Min = 0, Max = 14 },
                LogonDurationInMsConfig = new MetricConfiguration<int>() { Min = 10000, Max = 25000 },
                MemoryUsageConfig = new MetricConfiguration<decimal>() { Min = 0M, Max = 0.99M },
                SystemFreeSpaceInBytesConfig = new MetricConfiguration<long>() { Flip = false, Min = 1L, Max = 536870912000L },
            };

            _dpiCalculator = new DpiCalculator();
        }

        [Test]
        public void GivenDeviceInfoProducesCorrectDpi()
        {
            var device = new Device
            {
                DeviceId = 101,
                ClientId = 201,
                OfficeId = 301,
                BootSpeed = 235541,
                BsodCount = 0,
                CpuUsage = 0.009M,
                HardResetCount = 1,
                LogonDurationInMs = 19340,
                MemoryUsage = 0,
                SystemFreeSpaceInBytes = 177966186496L
            };

            var dpi = _dpiCalculator.CalculateDeviceDpi(device, _dpiConfiguration);

            Assert.AreEqual(6.722M, dpi);
        }

        [Test]
        public void GivenNullArgumentsThrowsException()
        {
            Assert.Throws(typeof(ArgumentNullException), () => _dpiCalculator.CalculateDeviceDpi(null, _dpiConfiguration));
            Assert.Throws(typeof(ArgumentNullException), () => _dpiCalculator.CalculateDeviceDpi(new Device(), null));
        }

        [Test]
        public void GivenInvalidConfigurationThrowsException()
        {
            var invalidDpiConfiguration = _dpiConfiguration;
            invalidDpiConfiguration.BsodCountConfig.Min = int.MaxValue;

            var device = new Device
            {
                DeviceId = 101,
                ClientId = 201,
                OfficeId = 301,
                BootSpeed = 235541,
                BsodCount = 0,
                CpuUsage = 0.009M,
                HardResetCount = 1,
                LogonDurationInMs = 19340,
                MemoryUsage = 0,
                SystemFreeSpaceInBytes = 177966186496L
            };

            Assert.Throws(typeof(ArgumentException), () => _dpiCalculator.CalculateDeviceDpi(device, invalidDpiConfiguration));

            invalidDpiConfiguration = _dpiConfiguration;
            invalidDpiConfiguration.HardResetCountConfig.Min = invalidDpiConfiguration.HardResetCountConfig.Max;

            Assert.Throws(typeof(ArgumentException), () => _dpiCalculator.CalculateDeviceDpi(device, invalidDpiConfiguration));
        }
    }
}