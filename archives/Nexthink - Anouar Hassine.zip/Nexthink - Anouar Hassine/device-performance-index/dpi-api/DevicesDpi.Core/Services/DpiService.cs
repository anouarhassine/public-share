﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Extensions.Logging;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using DevicesDpi.Core.Interfaces;
using DevicesDpi.Core.Entities;

namespace DevicesDpi.Core.Services
{
    public class DpiService : IDpiService
    {
        private IDeviceRepository _deviceRepository;
        private IConfigurationProvider _configurationProvider;
        private IDpiCalculator _dpiCalculator;
        private ILogger<DpiService> _logger;

        private Timer _timer;
        private static AutoResetEvent CanProcessEvent = new AutoResetEvent(false);

        public DpiService(
            IDeviceRepository deviceRepository,
            IConfigurationProvider configurationProvider,
            IDpiCalculator dpiCalculator,
            ILogger<DpiService> logger)
        {
            _deviceRepository = deviceRepository;
            _configurationProvider = configurationProvider;
            _dpiCalculator = dpiCalculator;
            _logger = logger;
        }

        public void Start()
        {
            CanProcessEvent.Set();

            _timer = new Timer(
                async e =>
                {
                    await ProcessDpiAsync();
                },
                null,
                TimeSpan.Zero,
                TimeSpan.FromMinutes(10));
        }

        public void Stop()
        {
            _timer.Dispose();
            _timer = null;
        }

        private async Task ProcessDpiAsync()
        {
            try
            {
                if (!CanProcessEvent.WaitOne(TimeSpan.FromMinutes(5)))
                {
                    _logger?.LogWarning("Skipping my turn");
                    return;
                }

                _logger?.LogInformation($"Starting DPI processing");

                var stopWatch = new Stopwatch();
                stopWatch.Start();
                var dpiConfiguration = await _configurationProvider.GetDpiConfigurationAsync();

                var pageSize = 10000;
                var paginatedDevices = await _deviceRepository.GetDevicesPaginatedAsync(
                    null,
                    null,
                    ValueOperator.LessThan,
                    0M,
                    null,
                    pageSize: pageSize);

                var devicesDpis = new Dictionary<int, decimal>();

                if (paginatedDevices.TotalRecords == 0)
                {
                    _logger?.LogInformation("No DPI calculation needed");
                    CanProcessEvent.Set();
                    return;
                }

                _logger?.LogInformation($"Calculating DPI for {paginatedDevices.TotalRecords} record(s)");

                foreach (var device in paginatedDevices.Data)
                {
                    var dpi = _dpiCalculator.CalculateDeviceDpi(device, dpiConfiguration);
                    devicesDpis[device.DeviceId] = dpi;
                }

                if (paginatedDevices.TotalPages > 1)
                {
                    for (var i = 2; i <= paginatedDevices.TotalPages; i++)
                    {
                        var nextPage = await _deviceRepository.GetDevicesPaginatedAsync(
                            null,
                            null,
                            ValueOperator.LessThan,
                            0M,
                            null,
                            pageNumber: i,
                            pageSize: pageSize);

                        foreach (var device in nextPage.Data)
                        {
                            var dpi = _dpiCalculator.CalculateDeviceDpi(device, dpiConfiguration);
                            devicesDpis[device.DeviceId] = dpi;
                        }
                    }
                }

                await _deviceRepository.BulkUpdateDevicesDpiAsync(devicesDpis);

                stopWatch.Stop();
                _logger?.LogInformation($"Finished DPI processing in {stopWatch.Elapsed.TotalSeconds} s");
            }
            catch(Exception e)
            {
                _logger?.LogError($"An error occured while processing DPI: {e}");
            }
            finally
            {
                CanProcessEvent.Set();
            }
        }
    }
}
