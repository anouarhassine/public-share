﻿using System;
using System.Collections.Generic;
using System.Text;
using DevicesDpi.Core.Entities;
using DevicesDpi.Core.Interfaces;

namespace DevicesDpi.Core.Services
{
    public class DpiCalculator : IDpiCalculator
    {
        public decimal CalculateDeviceDpi(Device device, DpiConfiguration dpiConfiguration)
        {
            if (device == null)
            {
                throw new ArgumentNullException(nameof(device));
            }

            if (dpiConfiguration == null)
            {
                throw new ArgumentNullException(nameof(dpiConfiguration));
            }

            var sum = 0M;

            sum += NormalizeMetric(device.BsodCount, dpiConfiguration.BsodCountConfig);
            sum += NormalizeMetric(device.BootSpeed, dpiConfiguration.BootSpeedConfig);
            sum += NormalizeMetric(device.HardResetCount, dpiConfiguration.HardResetCountConfig);
            sum += NormalizeMetric(device.LogonDurationInMs, dpiConfiguration.LogonDurationInMsConfig);
            sum += NormalizeMetric(device.MemoryUsage, dpiConfiguration.MemoryUsageConfig);
            sum += NormalizeMetric(device.SystemFreeSpaceInBytes, dpiConfiguration.SystemFreeSpaceInBytesConfig);
            sum += NormalizeMetric(device.CpuUsage, dpiConfiguration.CpuUsageConfig);

            var rawValue = (10M / 7M) * sum;

            return Math.Round(rawValue, 3);
        }

        private decimal NormalizeMetric<T>(T metricValue, MetricConfiguration<T> metricConfiguration) where T : struct
        {
            if (metricConfiguration == null)
            {
                throw new ArgumentNullException(nameof(metricConfiguration));
            }

            dynamic dMetric = metricValue;
            dynamic dMetricMin = metricConfiguration.Min;
            dynamic dMetricMax = metricConfiguration.Max;

            if (dMetricMin == dMetricMax)
            {
                throw new ArgumentException("Invalid metric configuration. Min and Max must have different values.");
            }

            if (dMetricMin > dMetricMax)
            {
                throw new ArgumentException("Invalid metric configuration. Min must be less than Max.");
            }

            decimal fraction = decimal.Divide(dMetric - dMetricMin, dMetricMax - dMetricMin);

            var max = Math.Max(0M, fraction);
            var normalizedValue = Math.Min(1M, max);
            return metricConfiguration.Flip ? 1 - normalizedValue : normalizedValue;
        }
    }
}
