﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using DevicesDpi.Core.Entities;
using DevicesDpi.Core.Interfaces;

namespace DevicesDpi.Core.Services
{
    public class ConfigurationProvider : IConfigurationProvider
    {
        private IDeviceRepository _deviceRepository;
        private ILogger<ConfigurationProvider> _logger;

        public ConfigurationProvider(IDeviceRepository deviceRepository, ILogger<ConfigurationProvider> logger)
        {
            _deviceRepository = deviceRepository;
            _logger = logger;
        }

        public async Task<DpiConfiguration> GetDpiConfigurationAsync()
        {
            var existingConfiguration = await _deviceRepository.GetDpiConfigurationAsync();

            if (existingConfiguration != null)
            {
                return existingConfiguration;
            }

            var bsodCounts = await _deviceRepository.GetSortedBsodCountsAsync();
            var bsodCountConfig = GetMetricConfiguration(bsodCounts, true);

            var hardResetCounts = await _deviceRepository.GetSortedHardResetCountsAsync();
            var hardResetCountConfig = GetMetricConfiguration(hardResetCounts, true);

            var bootSpeeds = await _deviceRepository.GetSortedBootSpeedsAsync();
            var bootSpeedConfig = GetMetricConfiguration(bootSpeeds, true);

            var logonDurations = await _deviceRepository.GetSortedLogonDurationsAsync();
            var logonDurationConfig = GetMetricConfiguration(logonDurations, true);

            var cpuUsages = await _deviceRepository.GetSortedCpuUsagesAsync();
            var cpuUsageConfig = GetMetricConfiguration(cpuUsages, true);

            var memoryUsages = await _deviceRepository.GetSortedMemoryUsagesAsync();
            var memoryUsageConfig = GetMetricConfiguration(memoryUsages, true);

            var systemFreeSpaces = await _deviceRepository.GetSortedSystemFreeSpacesAsync();
            var systemFreeSpaceConfig = GetMetricConfiguration(systemFreeSpaces, false);

            var configuration = new DpiConfiguration
            {
                BsodCountConfig = bsodCountConfig,
                HardResetCountConfig = hardResetCountConfig,
                BootSpeedConfig = bootSpeedConfig,
                LogonDurationInMsConfig = logonDurationConfig,
                CpuUsageConfig = cpuUsageConfig,
                MemoryUsageConfig = memoryUsageConfig,
                SystemFreeSpaceInBytesConfig = systemFreeSpaceConfig
            };

            await _deviceRepository.InsertDpiConfiguration(configuration);

            return configuration;
        }

        public MetricConfiguration<T> GetMetricConfiguration<T>(List<T> values, bool flip, bool sort = false)
            where T : IComparable<T>
        {
            if (sort)
            {
                values.Sort();
            }

            var percentile2ndRank = Math.Ceiling((2 / 100M) * values.Count) - 1;
            var percentile98thRank = Math.Ceiling((98 / 100M) * values.Count) - 1;

            var minIndex = (int)percentile2ndRank;
            var maxIndex = (int)percentile98thRank;

            if (values[minIndex].CompareTo(values[maxIndex]) == 0)
            {
                var switchVar = true;
                do
                {
                    if (switchVar)
                    {
                        minIndex--;
                    }
                    else
                    {
                        maxIndex++;
                    }

                    switchVar = !switchVar;
                    
                }
                while (minIndex > 0 && maxIndex < values.Count - 1 && (values[minIndex].CompareTo(values[maxIndex]) == 0));
            }

            return new MetricConfiguration<T>
            {
                Min = values[minIndex],
                Max = values[maxIndex],
                Flip = flip
            };
        }
    }
}
