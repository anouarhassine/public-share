﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DevicesDpi.Core.Interfaces
{
    public interface IDpiService
    {
        void Start();
        void Stop();
    }
}
