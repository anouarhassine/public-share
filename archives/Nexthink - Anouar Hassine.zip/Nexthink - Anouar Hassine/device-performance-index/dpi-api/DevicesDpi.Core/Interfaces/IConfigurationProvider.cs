﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

using DevicesDpi.Core.Entities;

namespace DevicesDpi.Core.Interfaces
{
    public interface IConfigurationProvider
    {
        Task<DpiConfiguration> GetDpiConfigurationAsync();

        MetricConfiguration<T> GetMetricConfiguration<T>(List<T> values, bool flip, bool sort = false)
            where T : IComparable<T>;
    }
}
