﻿using System;
using System.Collections.Generic;
using System.Text;
using DevicesDpi.Core.Entities;

namespace DevicesDpi.Core.Interfaces
{
    public interface IDpiCalculator
    {
        decimal CalculateDeviceDpi(Device device, DpiConfiguration dpiConfiguration);
    }
}
