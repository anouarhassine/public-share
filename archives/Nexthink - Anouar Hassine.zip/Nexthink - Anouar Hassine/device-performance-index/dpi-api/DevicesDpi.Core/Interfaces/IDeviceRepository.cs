﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

using DevicesDpi.Core.Entities;

namespace DevicesDpi.Core.Interfaces
{
    public interface IDeviceRepository
    {
        Task<Device> GetDeviceByIdAsync(int id);

        Task<PaginatedResult<Device>> GetDevicesPaginatedAsync(
            int? clientId,
            int? officeId,
            ValueOperator? valueOperator,
            decimal? dpiValue,
            decimal? dpiValueHigh,
            int pageNumber = 1,
            int pageSize = 10);

        Task<List<int>> GetSortedBsodCountsAsync();

        Task<List<int>> GetSortedHardResetCountsAsync();

        Task<List<int>> GetSortedBootSpeedsAsync();

        Task<List<int>> GetSortedLogonDurationsAsync();

        Task<List<decimal>> GetSortedCpuUsagesAsync();

        Task<List<decimal>> GetSortedMemoryUsagesAsync();

        Task<List<long>> GetSortedSystemFreeSpacesAsync();

        Task<bool> BulkUpdateDevicesDpiAsync(Dictionary<int, decimal> devicesDpis);

        Task<DpiConfiguration> GetDpiConfigurationAsync();

        Task InsertDpiConfiguration(DpiConfiguration dpiConfiguration);

        Task<bool> UpdateDpiConfigurationAsync(DpiConfiguration dpiConfiguration);
    }
}
