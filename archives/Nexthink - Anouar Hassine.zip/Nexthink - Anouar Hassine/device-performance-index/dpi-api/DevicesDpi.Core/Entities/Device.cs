﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevicesDpi.Core.Entities
{
    public class Device
    {
        public int DeviceId { get; set; }
        public int OfficeId { get; set; }
        public int ClientId { get; set; }

        public int BsodCount { get; set; }
        public int HardResetCount { get; set; }
        public int BootSpeed { get; set; }
        public int LogonDurationInMs { get; set; }
        public decimal CpuUsage { get; set; }
        public decimal MemoryUsage { get; set; }
        public long SystemFreeSpaceInBytes { get; set; }

        public decimal Dpi { get; set; }

        public DateTime LastUpdateTime { get; set; }
    }
}
