﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevicesDpi.Core.Entities
{
    public enum ValueOperator
    {
        Equals = 1,
        GreaterThan = 2,
        LessThan = 3,
        Between = 4
    }
}
