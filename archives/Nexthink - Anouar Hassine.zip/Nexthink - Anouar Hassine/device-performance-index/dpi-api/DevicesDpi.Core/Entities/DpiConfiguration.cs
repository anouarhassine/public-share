﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevicesDpi.Core.Entities
{
    public class DpiConfiguration
    {
        public int ConfigurationId { get; set; }
        public MetricConfiguration<int> BsodCountConfig { get; set; }
        public MetricConfiguration<int> HardResetCountConfig { get; set; }
        public MetricConfiguration<int> BootSpeedConfig { get; set; }
        public MetricConfiguration<int> LogonDurationInMsConfig { get; set; }
        public MetricConfiguration<decimal> CpuUsageConfig { get; set; }
        public MetricConfiguration<decimal> MemoryUsageConfig { get; set; }
        public MetricConfiguration<long> SystemFreeSpaceInBytesConfig { get; set; }
    }
}
