﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevicesDpi.Core.Entities
{
    public class MetricConfiguration<T>
    {
        public T Min { get; set; }
        public T Max { get; set; }
        public bool Flip { get; set; } = true;
    }
}
