﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Serializers;
using DevicesDpi.Core.Entities;
using DevicesDpi.Core.Interfaces;

namespace DevicesDpi.Infrastructure.Data
{
    public class DeviceRepository : IDeviceRepository
    {
        private IMongoCollection<DbDevice> _devicesCollection;
        private IMongoCollection<DbDpiConfiguration> _dpiConfigCollection;
        private ILogger<DeviceRepository> _logger;

        static DeviceRepository()
        {
            BsonSerializer.RegisterSerializer(typeof(decimal), new DecimalSerializer(BsonType.Decimal128));
            BsonSerializer.RegisterSerializer(typeof(decimal?), new NullableSerializer<decimal>(new DecimalSerializer(BsonType.Decimal128)));
        }

        public DeviceRepository(DeviceRepositorySettings deviceRepositorySettings, ILogger<DeviceRepository> logger)
        {
            _logger = logger;
            
            MongoClient dbClient = new MongoClient(deviceRepositorySettings.ConnectionString);

            var db = dbClient.GetDatabase(deviceRepositorySettings.DatabaseName);
            _devicesCollection = db.GetCollection<DbDevice>(deviceRepositorySettings.DevicesCollectionName);

            _dpiConfigCollection = db.GetCollection<DbDpiConfiguration>(deviceRepositorySettings.DpiConfigCollectionName);

            if (_dpiConfigCollection == null)
            {
                db.CreateCollection(deviceRepositorySettings.DpiConfigCollectionName);
                _dpiConfigCollection = db.GetCollection<DbDpiConfiguration>(deviceRepositorySettings.DpiConfigCollectionName);
            }
        }

        public async Task<Device> GetDeviceByIdAsync(int id)
        {
            try
            {
                var dbDevice = await _devicesCollection.Find(d => d.DeviceId == id)?.FirstOrDefaultAsync();

                if (dbDevice != null)
                {
                    return dbDevice.ToDevice();
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Error occured while fethcing device by Id: {e}");
            }

            return null;
        }

        public async Task<PaginatedResult<Device>> GetDevicesPaginatedAsync(
            int? clientId,
            int? officeId,
            ValueOperator? valueOperator,
            decimal? dpiValue,
            decimal?dpiValueHigh,
            int pageNumber = 1,
            int pageSize = 10)
        {
            try
            {
                Expression<Func<DbDevice, bool>> filter = d => true;
                var builder = Builders<DbDevice>.Filter;

                var searchFilter = builder.Empty;

                if (clientId.HasValue)
                {
                    searchFilter = searchFilter & builder.Eq(d => d.ClientId, clientId.Value);
                }

                if (officeId.HasValue)
                {
                    searchFilter = searchFilter & builder.Eq(d => d.OfficeId, officeId.Value);
                }

                if (valueOperator.HasValue && dpiValue.HasValue)
                {
                    switch (valueOperator)
                    {
                        case ValueOperator.Equals:
                            searchFilter = searchFilter & builder.Eq(d => d.Dpi, dpiValue.Value);
                            break;
                        case ValueOperator.GreaterThan:
                            searchFilter = searchFilter & builder.Gt(d => d.Dpi, dpiValue.Value);
                            break;
                        case ValueOperator.LessThan:
                            searchFilter = searchFilter & builder.Lt(d => d.Dpi, dpiValue.Value);
                            break;
                        default:
                            break;
                    }

                    if (valueOperator == ValueOperator.Between && dpiValueHigh.HasValue)
                    {
                        searchFilter = searchFilter 
                            & builder.Gt(d => d.Dpi, dpiValue.Value)
                            & builder.Lt(d => d.Dpi, dpiValueHigh.Value);
                    }
                }

                var validPageNumber = pageNumber < 1 ? 1 : pageNumber;
                var validPageSize = pageSize > 20 ? 20 : pageSize;

                var dbDevices = await _devicesCollection
                    .Find(searchFilter)
                    .Skip((validPageNumber - 1) * validPageSize)
                    .Limit(validPageSize)
                    .ToListAsync();

                var totalCount = await _devicesCollection.Find(searchFilter).CountDocumentsAsync();
                var totalPages = decimal.Divide(totalCount, validPageSize);
                int roundedTotalPages = Convert.ToInt32(Math.Ceiling(totalPages));
                var devices = dbDevices.Select(e => e.ToDevice()).ToList();

                return new PaginatedResult<Device>
                {
                    PageNumber = pageNumber,
                    PageSize = pageSize,
                    TotalRecords = (int)totalCount,
                    TotalPages = roundedTotalPages,
                    Data = devices
                };
            }
            catch (Exception e)
            {
                _logger.LogError($"Error occured while fethcing devices: {e}");
            }

            return null;
        }

        public async Task<bool> BulkUpdateDevicesDpiAsync(Dictionary<int,decimal> devicesDpis)
        {
            try
            {
                var bulkOperations = new List<WriteModel<DbDevice>>();

                foreach (var device in devicesDpis)
                {
                    var updateOne = new UpdateOneModel<DbDevice>(
                        Builders<DbDevice>.Filter.Where(x => x.DeviceId == device.Key),
                        Builders<DbDevice>.Update
                            .Set(d => d.Dpi, device.Value)
                            .Set(d => d.LastUpdateTime, DateTime.UtcNow));

                    bulkOperations.Add(updateOne);
                }

                var result = await _devicesCollection.BulkWriteAsync(bulkOperations);
                return result.IsAcknowledged;
            }
            catch (Exception e)
            {
                _logger?.LogError($"An error occured during bulk update: {e}");
            }

            return false;
        }

        public async Task<List<int>> GetSortedBsodCountsAsync()
        {
            return await GetSortedMetricAsync(d => d.BsodCount, d => d.BsodCount);
        }

        public async Task<List<int>> GetSortedHardResetCountsAsync()
        {
            return await GetSortedMetricAsync(d => d.HardResetCount, d => d.HardResetCount);
        }

        public async Task<List<int>> GetSortedBootSpeedsAsync()
        {
            return await GetSortedMetricAsync(d => d.BootSpeed, d => d.BootSpeed);
        }

        public async Task<List<int>> GetSortedLogonDurationsAsync()
        {
            return await GetSortedMetricAsync(d => d.LogonDurationInMs, d => d.LogonDurationInMs);
        }

        public async Task<List<decimal>> GetSortedCpuUsagesAsync()
        {
            return await GetSortedMetricAsync(d => d.CpuUsage, d => d.CpuUsage);
        }

        public async Task<List<decimal>> GetSortedMemoryUsagesAsync()
        {
            return await GetSortedMetricAsync(d => d.MemoryUsage, d => d.MemoryUsage);
        }

        public async Task<List<long>> GetSortedSystemFreeSpacesAsync()
        {
            return await GetSortedMetricAsync(d => d.SystemFreeSpaceInBytes, d => d.SystemFreeSpaceInBytes);
        }

        private async Task<List<T>> GetSortedMetricAsync<T>(
            Expression<Func<DbDevice, object>> sortSelector, 
            Expression<Func<DbDevice, T>> projectionSelector)
        {
            return await _devicesCollection
                .Find(d => true)
                .SortBy(sortSelector)
                .Project(projectionSelector)
                .ToListAsync();
        }

        public async Task<DpiConfiguration> GetDpiConfigurationAsync()
        {
            try
            {
                var dbDpiConfiguration = await _dpiConfigCollection
                                            .Find(c => true)
                                            .FirstOrDefaultAsync();

                if (dbDpiConfiguration != null)
                {
                    return dbDpiConfiguration.ToDpiConfiguration();
                }
            }
            catch(Exception e)
            {
                _logger?.LogError($"An error occured while fetching Dpi configuration: {e}");
            }

            return null;
        }

        public async Task<bool> UpdateDpiConfigurationAsync(DpiConfiguration dpiConfiguration)
        {
            try
            {
                var filter = Builders<DbDpiConfiguration>.Filter.Where(x => x.ConfigurationId == dpiConfiguration.ConfigurationId);
                var update = Builders<DbDpiConfiguration>.Update
                            .Set(d => d.BsodCountConfig, dpiConfiguration.BsodCountConfig)
                            .Set(d => d.BootSpeedConfig, dpiConfiguration.BootSpeedConfig)
                            .Set(d => d.LogonDurationInMsConfig, dpiConfiguration.LogonDurationInMsConfig)
                            .Set(d => d.HardResetCountConfig, dpiConfiguration.HardResetCountConfig)
                            .Set(d => d.CpuUsageConfig, dpiConfiguration.CpuUsageConfig)
                            .Set(d => d.MemoryUsageConfig, dpiConfiguration.MemoryUsageConfig)
                            .Set(d => d.SystemFreeSpaceInBytesConfig, dpiConfiguration.SystemFreeSpaceInBytesConfig);

                var result = await _dpiConfigCollection.UpdateOneAsync(filter, update);
                return result.IsAcknowledged;

            }
            catch (Exception e)
            {
                _logger?.LogError($"An error occured during bulk update: {e}");
            }

            return false;
        }

        public async Task InsertDpiConfiguration(DpiConfiguration dpiConfiguration)
        {
            try
            {
                await _dpiConfigCollection.InsertOneAsync(new DbDpiConfiguration(dpiConfiguration));
            }
            catch (Exception e)
            {
                _logger?.LogError($"An error occured during DPI configuration insert: {e}");
            }
        }
    }
}
