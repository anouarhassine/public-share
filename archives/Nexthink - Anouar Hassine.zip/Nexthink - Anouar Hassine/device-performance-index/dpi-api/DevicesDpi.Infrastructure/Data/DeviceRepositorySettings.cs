﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevicesDpi.Infrastructure.Data
{
    public class DeviceRepositorySettings
    {
        public string ConnectionString { get; set; }

        public string DatabaseName { get; set; }

        public string DevicesCollectionName { get; set; }

        public string DpiConfigCollectionName { get; set; }
    }
}
