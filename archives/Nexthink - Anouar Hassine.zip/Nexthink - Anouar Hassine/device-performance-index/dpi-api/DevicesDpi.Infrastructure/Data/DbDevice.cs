﻿using System;
using System.Collections.Generic;
using System.Text;

using DevicesDpi.Core.Entities;

using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace DevicesDpi.Infrastructure.Data
{

    public class DbDevice : Device
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        public Device ToDevice()
        {
            return new Device
            {
                DeviceId = DeviceId,
                ClientId = ClientId,
                OfficeId = OfficeId,
                BsodCount = BsodCount,
                HardResetCount = HardResetCount,
                BootSpeed = BootSpeed,
                CpuUsage = CpuUsage,
                MemoryUsage = MemoryUsage,
                SystemFreeSpaceInBytes = SystemFreeSpaceInBytes,
                LogonDurationInMs = LogonDurationInMs,
                Dpi = Dpi,
                LastUpdateTime = LastUpdateTime
            };
        }
    }
}
