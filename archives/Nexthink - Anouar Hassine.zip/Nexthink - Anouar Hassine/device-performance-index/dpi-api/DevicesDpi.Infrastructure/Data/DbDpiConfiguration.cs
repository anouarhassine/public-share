﻿using System;
using System.Collections.Generic;
using System.Text;
using DevicesDpi.Core.Entities;

using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace DevicesDpi.Infrastructure.Data
{
    public class DbDpiConfiguration : DpiConfiguration
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        public DbDpiConfiguration()
        {
            
        }

        public DbDpiConfiguration(DpiConfiguration dpiConfiguration)
        {
            ConfigurationId = dpiConfiguration.ConfigurationId;
            BootSpeedConfig = dpiConfiguration.BootSpeedConfig;
            HardResetCountConfig = dpiConfiguration.HardResetCountConfig;
            BsodCountConfig = dpiConfiguration.BsodCountConfig;
            CpuUsageConfig = dpiConfiguration.CpuUsageConfig;
            LogonDurationInMsConfig = dpiConfiguration.LogonDurationInMsConfig;
            MemoryUsageConfig = dpiConfiguration.MemoryUsageConfig;
            SystemFreeSpaceInBytesConfig = dpiConfiguration.SystemFreeSpaceInBytesConfig;
        }

        public DpiConfiguration ToDpiConfiguration()
        {
            return new DpiConfiguration
            { 
                ConfigurationId = ConfigurationId,
                BootSpeedConfig = BootSpeedConfig,
                HardResetCountConfig = HardResetCountConfig,
                BsodCountConfig = BsodCountConfig,
                CpuUsageConfig = CpuUsageConfig,
                LogonDurationInMsConfig = LogonDurationInMsConfig,
                MemoryUsageConfig = MemoryUsageConfig,
                SystemFreeSpaceInBytesConfig = SystemFreeSpaceInBytesConfig
            };
        }
    }
}
