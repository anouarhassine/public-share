using System;

namespace DevicesDpi.Web
{
    public class Program
    {
        public static void Main(string[] args)
        {
            new Endpoint<Startup>().Start();
        }
    }
}
