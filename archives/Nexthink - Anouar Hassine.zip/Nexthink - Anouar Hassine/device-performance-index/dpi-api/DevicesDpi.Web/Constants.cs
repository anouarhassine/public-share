﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DevicesDpi.Web
{
    public static class Constants
    {
        public const string DEVICES_CONNECTION_STRING = "DEVICES_CONNECTION_STRING";

        public const string DEVICES_DB_NAME = "DEVICES_DB_NAME";

        public const string DEVICES_COLLECTION_NAME = "DEVICES_COLLECTION_NAME";

        public const string DPI_CONFIG_COLLECTION_NAME = "DPI_CONFIG_COLLECTION_NAME";
    }
}
