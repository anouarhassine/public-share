﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

using DevicesDpi.Core.Entities;
using DevicesDpi.Core.Interfaces;

namespace DevicesDpi.Web.Controllers
{
    [Route("api/[controller]")]
    public class DevicesController : ControllerBase
    {
        private readonly ILogger<DevicesController> _logger;
        private readonly IDeviceRepository _deviceRepository;

        public DevicesController(IDeviceRepository deviceRepository, ILogger<DevicesController> logger)
        {
            _deviceRepository = deviceRepository;
            _logger = logger;
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var device = await _deviceRepository.GetDeviceByIdAsync(id);

            if (device == null)
            {
                return NotFound();
            }

            return Ok(device);
        }

        [HttpGet]
        [Route("")]
        public async Task<IActionResult> GetFiltered(
            int? clientId,
            int? officeId,
            ValueOperator? valueOperator,
            decimal? dpiValue,
            decimal? dpiValueHigh,
            int pageNumber = 1,
            int pageSize = 10)
        {
            var devices = await _deviceRepository.GetDevicesPaginatedAsync(
                clientId,
                officeId,
                valueOperator,
                dpiValue,
                dpiValueHigh,
                pageNumber,
                pageSize);

            if (devices == null)
            {
                return NotFound();
            }

            return Ok(devices);
        }
    }
}
