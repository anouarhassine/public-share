using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

using DevicesDpi.Core.Interfaces;
using DevicesDpi.Core.Services;
using DevicesDpi.Infrastructure.Data;

namespace DevicesDpi.Web
{
    public class Startup
    {
        protected virtual string EndpointName { get; set; } = "Devices Endpoint";

        public void ConfigureServices(IServiceCollection services)
        {
            ConfigureApiDocumentationServices(services);

            services.AddCors(o => o.AddPolicy("AllowAll", builder =>
            {
                builder
                    .AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader();
            }));

            services.AddControllers()
                .AddNewtonsoftJson(options =>
                {
                    options.UseCamelCasing(true);
                    options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
                    //options.SerializerSettings.Converters = new List<JsonConverter>()
                    //{
                    //    new StringEnumConverter(),
                    //};
                });

            services.AddSingleton<DeviceRepositorySettings>(GetDeviceRepositorySettings());
            services.AddScoped<IDeviceRepository, DeviceRepository>();
            services.AddScoped<IConfigurationProvider, ConfigurationProvider>();
            services.AddTransient<IDpiCalculator, DpiCalculator>();
            services.AddSingleton<IDpiService, DpiService>();
        }

        private DeviceRepositorySettings GetDeviceRepositorySettings()
        {
            return new DeviceRepositorySettings
            {
                ConnectionString = Environment.GetEnvironmentVariable(Constants.DEVICES_CONNECTION_STRING),
                DatabaseName = Environment.GetEnvironmentVariable(Constants.DEVICES_DB_NAME),
                DevicesCollectionName = Environment.GetEnvironmentVariable(Constants.DEVICES_COLLECTION_NAME),
                DpiConfigCollectionName = Environment.GetEnvironmentVariable(Constants.DPI_CONFIG_COLLECTION_NAME)
            };
        }

        private void IntiDpi(IApplicationBuilder app)
        {
            var serviceProvider = app.ApplicationServices;
            var dpiService = serviceProvider.GetService<IDpiService>();
            dpiService.Start();
        }

        protected void ConfigureApiDocumentationServices(IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = $"{EndpointName} API", Version = "v1" });
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            IntiDpi(app);

            app.UseCors("AllowAll");

            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.DocumentTitle = $"{EndpointName} API";
                c.SwaggerEndpoint("/swagger/v1/swagger.json", $"{EndpointName} API V1");
            });

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
