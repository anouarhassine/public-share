﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NLog.Web;

namespace DevicesDpi.Web
{
    public class Endpoint<TStartup> where TStartup : Startup
    {
        protected virtual string ListeningUrl { get; set; } = "http://*:5000";

        public void Start()
        {
            CreateHostBuilder()
                .Build()
                .Run();

            NLog.LogManager.Shutdown();
        }

        public IWebHostBuilder CreateHostBuilder() =>

            new WebHostBuilder()
                .UseKestrel()
                .UseUrls(ListeningUrl)
                .UseStartup<TStartup>()
                .ConfigureLogging(logging =>
                {
                    logging.ClearProviders();
                    logging.SetMinimumLevel(LogLevel.Trace);
                })
                .UseNLog();
    }
}
