import { DpiFilter } from './dpiSearchCriteria';
import { DeviceInfo } from './deviceInfo';

export interface SearchState {
    deviceId?: number;
    clientId?: number;
    officeId?: number;
    dpiValue?: number;
    dpiFilter?: DpiFilter;
    dpiLow?: number;
    dpiHigh?: number;
    pageNumber?: number;
    pageSize?: number;
}

export interface DevicesData {
    pageNumber: number;
    pageSize: number;
    totalPages: number;
    totalRecords: number;
    data: DeviceInfo[];
}

export interface DevicesState {
    devicesData: DevicesData;
    isLoading: boolean;
    isInError: boolean;
}

export interface GlobalState {
    search: SearchState;
    device: DevicesState;
}