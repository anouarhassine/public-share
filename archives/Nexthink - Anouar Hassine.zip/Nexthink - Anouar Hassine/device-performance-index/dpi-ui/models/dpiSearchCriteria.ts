
export enum DpiFilter {
    //unknown = 'unknown',
    Equals = 1,
    GreaterThan = 2,
    LessThan = 3,
    Between = 4,
}

export interface SearchCriteria {
    deviceId?: number;
    clientId?: number;
    officeId?: number;
    dpiValue?: number;
    dpiFilter?: DpiFilter;
    dpiLow?: number;
    dpiHigh?: number;
    pageNumber?: number;
    pageSize?: number;
}