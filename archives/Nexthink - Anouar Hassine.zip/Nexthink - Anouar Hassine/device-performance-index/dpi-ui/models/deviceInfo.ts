
export interface DeviceInfo {
    deviceId: number;
    clientId: number;
    officeId: number;
    dpi: number;
}