import { Dispatch } from 'redux';
import axios from 'axios';
import { SearchCriteria } from '../models/dpiSearchCriteria';
import { DpiFilter } from '../models/dpiSearchCriteria';
import { DevicesData } from '../models/states';
import { backendBaseUrl } from '../settings';

export const DEVICE_SEARCH_STARTED = 'DEVICE_SEARCH_STARTED';
export const DEVICE_SEARCH_SUCCEEDED = 'DEVICE_SEARCH_SUCCEEDED';
export const DEVICE_SEARCH_FAILED = 'DEVICE_SEARCH_FAILED';

const getDevicesFetchUrl = (searchCriteria: SearchCriteria): string => {
  let fetchUrl = `${backendBaseUrl}/api/devices/`;

  if (searchCriteria.deviceId !== undefined) {
    return `${fetchUrl}${searchCriteria.deviceId}`;
  }

  let searchFilters = '';

  if (searchCriteria.clientId !== undefined) {
    searchFilters += `clientId=${searchCriteria.clientId}`;
  }

  if (searchCriteria.officeId !== undefined) {
    searchFilters += `&officeId=${searchCriteria.officeId}`;
  }

  if (searchCriteria.dpiFilter !== undefined) {
    if (searchCriteria.dpiFilter !== DpiFilter.Between
      && searchCriteria.dpiValue !== undefined) {
        searchFilters += `&valueOperator=${searchCriteria.dpiFilter}&dpiValue=${searchCriteria.dpiValue}`;
    } else if (searchCriteria.dpiFilter === DpiFilter.Between
              && searchCriteria.dpiLow !== undefined
              && searchCriteria.dpiHigh !== undefined) {
                searchFilters += `&valueOperator=${searchCriteria.dpiFilter}&dpiValue=${searchCriteria.dpiLow}&dpiValueHigh=${searchCriteria.dpiHigh}`;
    }
  }

  if (searchCriteria.pageNumber) {
    searchFilters += `&pageNumber=${searchCriteria.pageNumber}`;
  }

  if (searchCriteria.pageSize) {
    searchFilters += `&pageSize=${searchCriteria.pageSize}`;
  }

  if (searchFilters !== '') {
    fetchUrl += `?${searchFilters}`;
  }

  return fetchUrl;
}

const fetchDevices = (searchCriteria: SearchCriteria) => {
  return new Promise<DevicesData>((resolve, reject) => {
      axios.get(getDevicesFetchUrl(searchCriteria))
      .then(response => {
        if (searchCriteria.deviceId !== undefined) {
          const resultAsList = {
            pageNumber: 1,
            pageSize: 10,
            totalPages: 1,
            totalRecords: 1,
            data: [response.data]
          };

          resolve(resultAsList);
        } else {
          resolve(response.data);
        }
      })
      .catch(error => {
          if (error.response) {
            // The request was made and the server responded with a status code
            // that falls out of the range of 2xx
            //let reason = JSON.parse(error.response.data);
            reject(!!error.response.data.reason ? error.response.data.reason : 'Received error from server');
          } else if (error.request) {
            // The request was made but no response was received
            // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
            // http.ClientRequest in node.js
            reject('No response was received');
          } else {
            // Something happened in setting up the request that triggered an Error
            reject(error.message);
          }
      });
  });
}

export const searchStarted = (searchCriteria: SearchCriteria) => {
  return (dispatch: Dispatch) => {
      dispatch({type: DEVICE_SEARCH_STARTED, searchCriteria: searchCriteria});

      fetchDevices(searchCriteria)
      .then(devicesData => {
          if (devicesData.totalRecords === 0) {
            dispatch({type: DEVICE_SEARCH_FAILED, reaon: 'No results'});
          } else {
            dispatch({type: DEVICE_SEARCH_SUCCEEDED, devicesData: devicesData});
          }
      })
      .catch(reason => {
          dispatch({type: DEVICE_SEARCH_FAILED, reaon: reason});
      })
  }
}

export const searchSuccess = (devicesData: DevicesData) => {
  return {
      type: DEVICE_SEARCH_SUCCEEDED,
      devices: devicesData
  }
}

export const searchFail = (reason: string) => {
  return {
      type: DEVICE_SEARCH_FAILED,
      reason: reason
  }
}