import { render, screen } from "@testing-library/react";
import '@testing-library/jest-dom';
import Home from "./pages/index";

describe("App", () => {
  it("renders without crashing", () => {
    render(<Home />);
    expect(screen.getByText('Device Performance Indicator App')).toBeInTheDocument();
  });
});