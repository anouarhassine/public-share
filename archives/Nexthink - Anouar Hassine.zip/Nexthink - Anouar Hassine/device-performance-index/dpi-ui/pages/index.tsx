import Head from 'next/head';
import styles from '../styles/Home.module.css';
import DpiApp from './DpiApp';

const Home = () => {
  return (
    <div className={styles.container}>
      <Head>
        <title>DPI Dashboard</title>
        <link rel="icon" href="/speed.png" />
      </Head>

      <header className={styles.header}>
        <h1>Device Performance Indicator App</h1>
      </header>
      <main className={styles.main}>
        <DpiApp />
      </main>

      <footer className={styles.footer}>
        <p>
          Nexthink ©
        </p>
      </footer>
    </div>
  )
}

export default Home;
