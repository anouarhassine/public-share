import { createStore, applyMiddleware, compose } from 'redux'
import { Provider } from 'react-redux'
import { createLogger } from 'redux-logger';
import thunk from 'redux-thunk';
import rootReducer from '../reducers/rootReducer';
import DpiDetails from '../components/DpiDetails';

const logger = createLogger({collapsed: true});
const store = compose (applyMiddleware (thunk, logger))(createStore)(rootReducer);

const DpiApp = () => {
  return (
    <Provider store={store}>
      <DpiDetails/>
    </Provider>
  );
}

export default DpiApp;