
export const backendBaseUrl = process.env.NEXT_PUBLIC_DPI_API_URL;