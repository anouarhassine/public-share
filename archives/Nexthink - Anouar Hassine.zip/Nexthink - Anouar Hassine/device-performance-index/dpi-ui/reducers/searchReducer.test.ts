import searchReducer from './searchReducer';
import { SearchState } from '../models/states';
import { DEVICE_SEARCH_STARTED } from '../actions/deviceActions';
import { SearchCriteria, DpiFilter } from '../models/dpiSearchCriteria';

describe('search reducer', () => {
    it('sets search state fields when a search is started', () => {
        const stateBefore: SearchState = {};
        const sentCriteria: SearchCriteria = {
            deviceId: 456,
            clientId: 2,
            officeId: 487,
            dpiFilter: DpiFilter.Between,
            dpiLow: 2.3,
            dpiHigh: 8.1,
            pageNumber: 2,
        };
        const newState = searchReducer(stateBefore, {type: DEVICE_SEARCH_STARTED, searchCriteria: sentCriteria});
        expect(newState.deviceId).toEqual(sentCriteria.deviceId);
        expect(newState.clientId).toEqual(sentCriteria.clientId);
        expect(newState.officeId).toEqual(sentCriteria.officeId);
        expect(newState.dpiFilter).toEqual(sentCriteria.dpiFilter);
        expect(newState.dpiLow).toEqual(sentCriteria.dpiLow);
        expect(newState.dpiHigh).toEqual(sentCriteria.dpiHigh);
        expect(newState.pageNumber).toEqual(sentCriteria.pageNumber);
    });
});