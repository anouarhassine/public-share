import { combineReducers } from 'redux';
import devicesReducer from './devicesReducer';
import searchReducer from './searchReducer';

export default combineReducers({
    device: devicesReducer,
    search: searchReducer
});