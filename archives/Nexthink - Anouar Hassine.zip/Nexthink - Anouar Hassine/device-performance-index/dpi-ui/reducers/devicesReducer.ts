import { Reducer } from 'redux';
import { DevicesState, DevicesData } from '../models/states';
import { DEVICE_SEARCH_STARTED, DEVICE_SEARCH_SUCCEEDED, DEVICE_SEARCH_FAILED } from '../actions/deviceActions';

const defaultState: DevicesState = {
    devicesData: {
        pageNumber: 0,
        pageSize: 10,
        totalPages: 0,
        totalRecords: 0,
        data: []
    },
    isInError: false,
    isLoading: false,
};

const deviceFetchStartedHandler = (state: DevicesState): DevicesState => {
    return {
        ...state,
        isLoading: true
    };
}

const deviceFetchSucceededHandler = (state: DevicesState, devicesData: DevicesData): DevicesState => {
    return {
        ...state,
        devicesData: devicesData,
        isInError: false,
        isLoading: false
    };
}

const deviceFetchFailedHandler = (state: DevicesState, reason: any): DevicesState => {
    return {
        ...state,
        devicesData: {
            ...defaultState.devicesData
        },
        isInError: true,
        isLoading: false
    };
}

const devicesReducer: Reducer<DevicesState> = (state: DevicesState = defaultState, action: any) => {
    switch (action.type) {
        case DEVICE_SEARCH_STARTED:
            return deviceFetchStartedHandler(state);
        case DEVICE_SEARCH_SUCCEEDED:
            return deviceFetchSucceededHandler(state, action.devicesData);
        case DEVICE_SEARCH_FAILED:
            return deviceFetchFailedHandler(state, action.reason);
        default:
            return state;
    }
  }
  
  export default devicesReducer;