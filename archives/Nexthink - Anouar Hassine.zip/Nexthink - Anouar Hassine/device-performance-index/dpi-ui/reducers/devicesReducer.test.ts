import devicesReducer from './devicesReducer';
import { DevicesState } from '../models/states';
import { DEVICE_SEARCH_STARTED, DEVICE_SEARCH_SUCCEEDED, DEVICE_SEARCH_FAILED } from '../actions/deviceActions';

describe('devices reducer', () => {
    it('sets loading flag and resets error flag when starting a search', () => {
        const stateBefore: DevicesState = {
            devicesData: {
                pageNumber: 0,
                pageSize: 10,
                totalPages: 0,
                totalRecords: 0,
                data: []
            },
            isInError: false,
            isLoading: false,
        };
        const newState = devicesReducer(stateBefore, {type: DEVICE_SEARCH_STARTED});
        expect(newState.isLoading).toBeTruthy();
        expect(newState.isInError).toBeFalsy();
    });

    it('sets correct flags and data when search succeeds', () => {
        const stateBefore: DevicesState = {
            devicesData: {
                pageNumber: 0,
                pageSize: 10,
                totalPages: 0,
                totalRecords: 0,
                data: []
            },
            isInError: false,
            isLoading: true,
        };

        const receivedData = {
            pageNumber: 1,
            pageSize: 10,
            totalPages: 1,
            totalRecords: 2,
            data: [
                {
                    deviceId: 101,
                    clientId: 102,
                    officeId: 103,
                    dpi: 5.5,
                },
                {
                    deviceId: 201,
                    clientId: 202,
                    officeId: 203,
                    dpi: 7.6,
                },
            ]
        };
        const newState = devicesReducer(stateBefore, {type: DEVICE_SEARCH_SUCCEEDED, devicesData: receivedData});
        expect(newState.isLoading).toBeFalsy();
        expect(newState.isInError).toBeFalsy();
        expect(newState.devicesData).toEqual(receivedData);
    });

    it('sets error flag and resets loading flag when a search fails', () => {
        const stateBefore: DevicesState = {
            devicesData: {
                pageNumber: 0,
                pageSize: 10,
                totalPages: 0,
                totalRecords: 0,
                data: []
            },
            isInError: false,
            isLoading: true,
        };
        const newState = devicesReducer(stateBefore, {type: DEVICE_SEARCH_FAILED, reason: 'some reason'});
        expect(newState.isLoading).toBeFalsy();
        expect(newState.isInError).toBeTruthy();
        expect(newState.devicesData.data.length).toBe(0);
    });
});