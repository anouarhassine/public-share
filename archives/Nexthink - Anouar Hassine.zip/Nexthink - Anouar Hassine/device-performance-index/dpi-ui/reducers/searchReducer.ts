import { Reducer } from 'redux';
import { SearchState } from '../models/states';
import { DEVICE_SEARCH_STARTED } from '../actions/deviceActions';
import { SearchCriteria } from '../models/dpiSearchCriteria';

const defaultState: SearchState = {
    pageSize: 10
};

const searchCriteriaChangedHandler = (state: SearchState, searchCriteria: SearchCriteria): SearchState => {
    return {
        ...state,
        deviceId: searchCriteria.deviceId,
        clientId: searchCriteria.clientId,
        officeId: searchCriteria.officeId,
        dpiFilter: searchCriteria.dpiFilter,
        dpiValue: searchCriteria.dpiValue,
        dpiLow: searchCriteria.dpiLow,
        dpiHigh: searchCriteria.dpiHigh,
        pageNumber: searchCriteria.pageNumber,
        pageSize: searchCriteria.pageSize || state.pageSize
    };
}

const devicesReducer: Reducer<SearchState> = (state: SearchState = defaultState, action: any) => {
    switch (action.type) {
        case DEVICE_SEARCH_STARTED:
            return searchCriteriaChangedHandler(state, action.searchCriteria);
        default:
            return state;
    }
  }
  
  export default devicesReducer;