const { defaults } = require('jest-config');

module.exports = {
    testMatch: ['**/*test.[jt]s?(x)'],
    moduleFileExtensions: [...defaults.moduleFileExtensions, 'ts', 'tsx'],
    testPathIgnorePatterns: ["<rootDir>/.next/", "<rootDir>/node_modules/", "<rootDir>/.git/"],
    //setupFilesAfterEnv: ["<rootDir>/setupTests.js"],
    globals: {
        'ts-jest': {
            tsConfig: 'tsconfig.json',
            isolatedModules: false,
            babelConfig: true,
            diagnostics: false,
        },
    },
    preset: 'ts-jest',
    moduleNameMapper: {
        '^components$': '<rootDir>/components',
        '^components/(.+)$': '<rootDir>/components/$1',
        '^pages$': '<rootDir>/pages',
        '^pages/(.+)$': '<rootDir>/pages/$1',
        '\\.(css)$': 'identity-obj-proxy',
    },
    transform: {
      ".(ts|tsx)": "babel-jest"
    },
    transformIgnorePatterns: ['<rootDir>/node_modules/'],
};