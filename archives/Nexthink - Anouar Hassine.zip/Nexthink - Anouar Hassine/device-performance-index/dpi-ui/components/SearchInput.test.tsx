import { screen } from "@testing-library/react";
import '@testing-library/jest-dom';
import { renderForTest } from '../utils/testingUtils';
import SearchInput from "./SearchInput";

describe("<SearchInput />", () => {
  it("renders search elements", () => {
    renderForTest(<SearchInput />);
    expect(screen.getByRole('button', {name: 'search devices'})).toBeVisible();
    expect(screen.getByLabelText(/device id/i)).toBeVisible();
    expect(screen.getByLabelText(/client id/i)).toBeVisible();
    expect(screen.getByLabelText(/office id/i)).toBeVisible();
    expect(screen.getByLabelText(/^dpi value$/)).toBeVisible();
    expect(screen.getByLabelText(/^dpi value from$/)).toBeVisible();
    expect(screen.getByLabelText(/^dpi value to$/)).toBeVisible();
  });
});