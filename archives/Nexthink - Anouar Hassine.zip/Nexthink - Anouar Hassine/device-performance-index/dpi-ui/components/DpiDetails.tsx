import Container from '@material-ui/core/Container';
import SearchInput from './SearchInput';
import Devices from './Devices';

const DpiDetails = () => {
  return (
    <Container component="main">
        <SearchInput />
        <Devices />
    </Container>
  );
}

export default DpiDetails;