import { useState } from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import LinearProgress from '@material-ui/core/LinearProgress';
import TablePagination from '@material-ui/core/TablePagination';
import Checkbox from '@material-ui/core/Checkbox';
import Alert from '@material-ui/lab/Alert';
import { withStyles, Theme, createStyles, makeStyles } from '@material-ui/core/styles';
import { useSelector, useDispatch } from 'react-redux';
import { GlobalState, DevicesData, SearchState } from '../models/states';
import { searchStarted } from '../actions/deviceActions';

const StyledHeaderCell = withStyles((_: Theme) =>
  createStyles({
    head: {
      backgroundColor: '#C7CEEA',
      fontWeight: 'bold',
      //color: theme.palette.common.white,
    },
    body: {
      fontSize: 14,
    },
  })
)(TableCell);

const Devices = () => {
    const dispatch = useDispatch();
    const isLoading: boolean = useSelector((state: GlobalState) => state.device.isLoading);
    const isInError: boolean = useSelector((state: GlobalState) => state.device.isInError);
    const devicesData: DevicesData = useSelector((state: GlobalState) => state.device.devicesData);
    const searchState: SearchState = useSelector((state: GlobalState) => state.search);

    const [selectAll, setSelectAll] = useState(false);
    
    const defaultDeviceToChecked = devicesData.data.reduce((result, item) => {
            result[item.deviceId.toString()] = false;
            return result;
        }, {});
    
    const allSelectedDeviceToChecked = devicesData.data.reduce((result, item) => {
        result[item.deviceId.toString()] = true;
        return result;
    }, {});

    const [deviceToChecked, setDeviceToChecked] = useState(defaultDeviceToChecked);

    const handlePageChange = (newPage: number) => {
        dispatch(searchStarted(
            {
                deviceId: searchState.deviceId,
                clientId: searchState.clientId,
                officeId: searchState.officeId,
                dpiFilter: searchState.dpiFilter,
                dpiValue: searchState.dpiValue,
                dpiHigh: searchState.dpiHigh,
                dpiLow: searchState.dpiLow,
                pageNumber: newPage + 1,
                pageSize: searchState.pageSize
            }
        ));
    }

    const handlePageSizeChange = (newPageSize: number) => {
        dispatch(searchStarted(
            {
                deviceId: searchState.deviceId,
                clientId: searchState.clientId,
                officeId: searchState.officeId,
                dpiFilter: searchState.dpiFilter,
                dpiValue: searchState.dpiValue,
                dpiHigh: searchState.dpiHigh,
                dpiLow: searchState.dpiLow,
                pageNumber: 1,
                pageSize: newPageSize
            }
        ));
    }

    const handleItemSelectionChanged = (deviceId: number, checked: boolean) => {
        if (checked && !deviceToChecked[deviceId.toString()]) {
            const newDevicesToChecked = {
                ...deviceToChecked
            };
            newDevicesToChecked[deviceId.toString()] = true;
            setDeviceToChecked(newDevicesToChecked);
            return;
            }

        if (!checked && deviceToChecked[deviceId.toString()]) {
            const newDevicesToChecked = {
                ...deviceToChecked
            };
            newDevicesToChecked[deviceId.toString()] = false;
            setDeviceToChecked(newDevicesToChecked);
            if (selectAll) {
                setSelectAll(false);
            }
            return;
        }
    };

    const handleToggleAllChanged = (checked: boolean) => {
        if (!checked) {
            setDeviceToChecked(defaultDeviceToChecked);
        } else {
            setDeviceToChecked(allSelectedDeviceToChecked);
        }

        setSelectAll(checked);
    };

    const getAverageValueForSelectedItems = () => {
        const averageInfo = {
            sum: 0,
            count: 0,
        };
        devicesData.data.reduce((info, currentDevice) => {
            if (selectAll || deviceToChecked[currentDevice.deviceId.toString()]) {
                info.sum += currentDevice.dpi;
                info.count += 1;
            }
            return info;
        }, averageInfo);

        return averageInfo.count !== 0 ? (averageInfo.sum / averageInfo.count).toFixed(3) : 0;
    };

    const dpisAverage = (
        <div style={{display: "flex", flex: "1"}}>
            <p><u>Average DPI for selected items: </u>{getAverageValueForSelectedItems()}</p>
        </div>
    );

    const dpiTable = (
        isLoading ? <LinearProgress /> :
        <TableContainer component={Paper} style={{ maxHeight: 561 }}>
            <Table aria-label="customized table" stickyHeader={true} size="small">
            <TableHead>
                <TableRow>
                    <StyledHeaderCell>
                        <Checkbox
                            size="small"
                            disabled={!devicesData || !devicesData.data || devicesData.data.length === 0}
                            onChange={(_, checked) => {handleToggleAllChanged(checked)}} />
                    </StyledHeaderCell>
                    <StyledHeaderCell>Device Id</StyledHeaderCell>
                    <StyledHeaderCell>Client Id</StyledHeaderCell>
                    <StyledHeaderCell>Office Id</StyledHeaderCell>
                    <StyledHeaderCell>DPI</StyledHeaderCell>
                </TableRow>
            </TableHead>
            <TableBody>
                {devicesData.data.map((device) => (
                <TableRow key={device.deviceId}>
                    <TableCell>
                        <Checkbox 
                            size="small"
                            checked={deviceToChecked[device.deviceId.toString()] || selectAll || false}
                            onChange={(_, checked) => {handleItemSelectionChanged(device.deviceId, checked)}} />
                    </TableCell>
                    <TableCell component="th" scope="row">
                        {device.deviceId}
                    </TableCell>
                    <TableCell>{device.clientId}</TableCell>
                    <TableCell>{device.officeId}</TableCell>
                    <TableCell>{device.dpi}</TableCell>
                </TableRow>
                ))}
            </TableBody>
            </Table>
        </TableContainer>
    );

    const paginationControl = (
        !isLoading && 
        <TablePagination
                component="div"
                count={devicesData.totalRecords}
                page={(devicesData.pageNumber && (devicesData.pageNumber >= 1)) ? devicesData.pageNumber - 1 : 0}
                onChangePage={(_, page) => {handlePageChange(page)}}
                rowsPerPage={searchState.pageSize}
                //rowsPerPageOptions={[10]}
                onChangeRowsPerPage={(event) => {handlePageSizeChange(+event.target.value)}} />
    );

    const errorControl = (
        <Alert variant="outlined" severity="warning">No results for your query</Alert>
    );

    return (
        isInError ? 
        <>
            {errorControl}
        </> :
        <>
            {dpisAverage}
            {dpiTable}
            {paginationControl}
        </>
    );
}

export default Devices;