import { TextField } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import MenuItem from '@material-ui/core/MenuItem';
import { makeStyles } from '@material-ui/core/styles';
import { DpiFilter } from '../models/dpiSearchCriteria';
import { searchStarted } from '../actions/deviceActions';
import { useCallback, useState } from 'react';
import { useDispatch } from 'react-redux';

const filterTypes = ["Equals", "LessThan", "GreaterThan", "Between"];

const useStyles = makeStyles((_) => ({
    root: {
      '& .MuiTextField-root': {
        //margin: theme.spacing(1),
        width: '25ch',
      },
      '& .search': {
          width: '25ch',
          "justify-content": 'center'
      }
    },
  }));

const SearchInput = () => {

    const classes = useStyles();

    const [deviceId, setDeviceId] = useState('');
    const [clientId, setClientId] = useState('');
    const [officeId, setOfficeId] = useState('');
    const [filterType, setFilterType] = useState('');
    const [dpiValue, setDpiValue] = useState('');
    const [dpiValueFrom, setDpiValueFrom] = useState('');
    const [dpiValueTo, setDpiValueTo] = useState('');

    const dispatch = useDispatch();

    const isDpiValueInputDisabled = useCallback(() :boolean => {
        return filterType === "Between";
    }, [filterType]);

    const areDpiValueRangesInvalid = () :boolean => {
        return filterType === "Between"
                && dpiValueFrom !== undefined
                && dpiValueTo !== undefined
                && dpiValueFrom > dpiValueTo;
    };

    const handleSearchClick = (e: any) => {
        const action = searchStarted({
            deviceId: deviceId ? parseInt(deviceId, 10) : undefined,
            clientId: clientId ? parseInt(clientId, 10) : undefined,
            officeId: officeId ? parseInt(officeId, 10) : undefined,
            dpiValue: dpiValue ?  parseFloat(dpiValue) : undefined,
            dpiFilter: filterType ? DpiFilter[filterType] : undefined,
            dpiLow: dpiValueFrom ?  parseFloat(dpiValueFrom) : undefined,
            dpiHigh: dpiValueTo ?  parseFloat(dpiValueTo) : undefined,
        });
        dispatch(action);
    };
    
    const filterItems = 
        filterTypes.map(e => <MenuItem key={e} value={e}>{e}</MenuItem>);

    const filterControl = () => {
        return (
            <TextField
                variant="outlined"
                label="Filter type"
                select
                size="small"
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
            >
                {filterItems}
            </TextField>
        );
    }

    return (
        <div className={classes.root} style={{display: "flex", flexDirection: "column", marginTop: "10px", marginBottom: "10px"}}>
            <div style={{display: "flex", flexDirection: "row", justifyContent: "space-between", marginTop: "10px", marginBottom: "10px"}}>
                <TextField aria-hidden={false} aria-label="device id" type="number" label="Device Id" variant="outlined" size="small" onChange={(e) => setDeviceId(e.target.value)} />
                <TextField aria-label="client id" type="number" label="Client Id" variant="outlined" size="small" onChange={(e) => setClientId(e.target.value)} />
                <TextField aria-label="office id" type="number" label="Office Id" variant="outlined" size="small" onChange={(e) => setOfficeId(e.target.value)} />
                <div className="search" style={{display: "flex", justifyContent: "flex-end", alignItems: "center"}}>
                    <Button 
                        aria-label="search devices" 
                        variant="contained" 
                        color="primary" 
                        disabled={areDpiValueRangesInvalid()} 
                        onClick={handleSearchClick}>
                        Search
                    </Button>
                </div>
            </div>
            <div style={{display: "flex", flexDirection: "row", justifyContent: "space-between", marginTop: "10px", marginBottom: "10px"}}>
                {filterControl()}
                <TextField 
                    aria-label="dpi value"
                    type="number"
                    label="DPI Value"
                    variant="outlined"
                    size="small"
                    disabled={isDpiValueInputDisabled()}
                    onChange={(e) => setDpiValue(e.target.value)} />
                <TextField
                    aria-label="dpi value from"
                    type="number"
                    label="DPI From"
                    variant="outlined"
                    size="small"
                    error={areDpiValueRangesInvalid()}
                    disabled={!isDpiValueInputDisabled()} 
                    onChange={(e) => setDpiValueFrom(e.target.value)} />
                <TextField
                    aria-label="dpi value to"
                    type="number"
                    label="DPI To"
                    variant="outlined"
                    size="small"
                    error={areDpiValueRangesInvalid()}
                    disabled={!isDpiValueInputDisabled()}
                    onChange={(e) => setDpiValueTo(e.target.value)} />
            </div>
        </div>
    );
};

export default SearchInput;