# Device Performance Indicator Service & App

The application is structured as follows:

- A MongoDB database running as a Docker container. The sample csv data was imported into it.
- An ASP.Net Core 3.1 application running as a DPI calculation service and offers a REST API to query the data.
- A React Front End application powered by Next Js, Typescript and Redux. It leverages the REST API to display the data.

Pagination was implemented in the backend service as well as the front end as the number of records is high (~65k). The user can choose between different page sizes in the UI (from 10 to 100).

When running the backend service for the 1st time, it performs the following steps:

1. Fetch DPI configuration (Min and Max). caculates them if not available and stores the result in the DB
2. Fetch the devices data from the DB by 10k rows batch where the DPI value is negative (meaning that it is not calculated yet)
3. Calculates the DPI values and flushes the database by a bulk write operation (for every 10k rows batch)

The estimated processing time is around 4-5 minutes. You should wait for the backend service to write the following log line: `Finished DPI processing in xxx s`.

I noticed that the percentile calculation for BSOD count gave two identical values so the normalization cannot be calculated (division by zero). To solve the problem, and when such a scenario occurs, the service tries to widen the interval by moving the Min and Maw index wider and wider until Min and Max have different values. For BSOD count the service ended up with the values 0 and 1 (the 65k records all have either 0 or 1).

## Prerequisites

The following components should be installed to able to build and run the applications:

- Node.js with npm: for the React Front End application
- dotnet (3.1 or higher): The cross platform .Net runtime for the Back End service
- Docker: for easily running the whole demo; DB + Backend service + Front End App

## Build

To build the necessary modules do the following:

In *dpi-api* folder

```shell
> dotnet publish ./DevicesDpi.Web/DevicesDpi.Web.csproj
```

In *dpi-ui* folder

```shell
> npm run install
> npm run build
```

## Start the demo

To start the demo go to *docker* folder and run the following commands:

```shell
> docker-compose build
> docker compose up -d
```

Open the browser and enter the following address where you can access the web application: `http://localhost:3000`

An Open API documentation page is available for the backend service at `http://localhost:5000/swagger`

## Key steps/features to implement before release

- Implement a authentication/authorization mechanism to control access to the application
- Setup integration tests
- Deploy the application to other environments before production for validation (UAT etc.)