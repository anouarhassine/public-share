<h1 align="center"><b>DPI Alerting Design</b></h1>

<h2><b>1. Requirements summary</b></h2>

The Device Performance Indicator infrastructure needs to be extended to support alert detection and notification.

<h3><b>Functional requirements</b></h3>

- DPI-related time series must be stored and be available for update and query
- Alerts must be automatically created when time series meet a specific condition
- Alerts are generated for two levels: devices and offices
- Alerts must be accessible via a Web UI
- Users must receive alerts as notifications
- The system is cross-client

<h3><b>Non Functional requirements</b></h3>

- System must be scalable to 1 billion devices distributed among 1000 clients
- Notifications must be sent in real time
- System must be highly available (no single point of failure)
- Highly performant: keep notification delivery latency as low as possible
- Durable: Alerts must not be lost. Subscriber must receive every message at least once.

<h2><b>2. Assumptions</b></h2>

- Metrics data sources: I assume that metrics reside in stores managed by the services which calculated them and that we do not want to change the behaviour to make those services send the metrics to the alerting system. Hence the use of data collectors.
- Alert levels: I assume that the level of an alert is defined by two sets of rules. One for devices (ex: if during the last 10 minutes the metric dropped significantly compared to a reference) and one for the office (ex: if during the last 10 minutes a certain number of devices are subject to an alert). 

<h2><b>3. Design main focus and components</b></h2>

According to the functional requirements, the system is devided into two main phases:
1. Monitoring phase: The DPI values and other metrics are monitored over time to detect an *anomaly*
2. Notification phase: The alert is created and must be delivered to the desired audience

The below diagram decribes the main components involved in the system with its two phases:

![DPI alert main components](pics/dpi-alert-main-components.svg)

<h2><b>4. Monitoring</b></h2>

<h3><b>Data collection</b></h3>

The metrics live in their actual storage which are the databases of the services that produces them. So a component is needed to export those metrics to the monitoring and alerting system.

Telegraf and Collectd are two popular solutions that can be used.
DPI values are sent to the system along with many other metrics (20). These are relative to millions of devices (~1 billion). Thus it is better to *stream* these values to a storage so they can be reliably processed.

I would suggest using Telegraf as it is more recent (2015) and has a fastly growing community. Like Collectd, it is plugin-driven. And, opposed to Collectd which is written in C, it is written in Go.

The streaming option would help the system be scalable enough in the data collection/ingestion part.

A message bus is suitable as a front end component that would receive the data. The multiple metrics generation services would be the publishers. And a multitude of replicated services would be the subscribers responsible for reading the metric-related message for storage and analysis.

Two main message bus solutions exist:
- RabbitMQ
- Apache Kafka

We would choose Kafka as it can handle 1 million messages/s compared to a few thousands for RabbitMQ. Its message retention policy can also be useful to guarantee message delivery.

<h3><b>Time Series processing and storage</b></h3>

A component should be listening to the flowing stream of data. It has two main responsibilities:
- Detect the *anomaly* in the incoming data point
- Save the data for the long term

This component will use a set of *rules* related to our use-case to raise an alert. In our case it would have a rule set for device level alerts and another one for office level alerts.

There are two main approaches to handle this use case:
1. Batching: Save the data flow directly to a Time Series database and regularly request the data for a particular window of time and try to detect the *anomaly*
2. Streaming: Stream the data to a component (we will call it stream processor) which keeps the desired time window of data <u>in memory</u> for *anomaly* detection. A Time Series database will be used either as a long term storage or as a target of the data flow with open connection to the stream processor.

Given the high volume of data received (~1 billion) I would suggest using the batching approach. The streaming approach would have to use a lot of memory to process the data.

I would suggest using Kapacitor for the processing and anomaly detection.

Many Time Series databases available in the market provide the support of Time Series aggregation and can be queried using a SQL-like language. Here is a comparison table for some of them:

| Database | Scales to many hosts | Supports time series aggregates | SQL-like query  | Free/paid | Cloud solution? | Notes |
| :--------------: |:-------------:| :-----:| :------: | :------: | :------: | :-------- |
| Prometheus | No | Yes | No | Free | No | More suitable for service performance monitoring |
| InfluxDB | Yes (paid) | Yes | Yes | Both | Paid | Part of a full satck solution to collect store and analyze data |
| Cassandra | Yes | No | Yes | Free | Yes | Not a purpose-built for time series data |
| Timescale DB | Yes | Yes | Yes | Both | Paid | Built on top of Postgres SQL |
| OpenTSDB | Yes | Yes | No | Free | No | Uses HBase for storage |
| AWS Timestream | Yes | Yes | Yes | Paid | Paid | A full cloud soltion provided by Amazon |


Scalability, time series aggregation support and cloud availability are the key characteristics that will influence our choice.

This would leave InfluxDB, Timescale DB and AWS Timestream. A cost comparison can be a deciding factor between these solutions. I would suggest using InfluxDB as it is provided by the same vendor who offers Kapacitor and Telegraf that we already chose. It is also easy to setup locally. Which makes it easier and faster to make a proof of concept for validation.

To send data to this database we will be using Telegraf, again, as it would act as an adapter from Kafka.

<h2><b>5. Alert generation</b></h2>

Once created, an alert is sent to the notification sub-system of our solution. Asynchronous posts to a message bus is a suitable option that gurantees scalability in case of high number of notifications and also high availability. Another Kafka bus should be used in this case.

<h3><b>Notification: Alerts delivery</b></h3>

The alert delivery sub-system is composed of three main components:
- A message retriever: Subscribes to the alerts messages bus and creates a dedicated task to handle each one
- A metadata store (database): that holds the info about the targetted audience for a given alert
- A service that would fetch the metadata related to a given alert and send the message to the proper audience

The message retriever would be a service that leverages Thread pooling to handle the alert messages it receives while being subscribed to the bus. The message is then sent to the delivery service. That latter would fetch the metadata from a store (which is a sort of registery holding the information about the targetted audience) and then would also leverage thread pooling to spawn a dedicated sender task for each type of notification (Email, SMS, etc.)

The list of targeted audience can be big: many email adresses and phone numbers. So a document-based NoSQL cloud database would be the best option to store this information. The activation of the office/device level notifications is also part of the information stored in this database.

To provide real-time alerts to a web UI, the final alert message is posted in a message bus to which a server is subscribed. That latter would be a Websocket server that would act as a bridge between the message bus and web clients.

<h2><b>6. Full picture</b></h2>

The full picture architecture diagram is as follows:

![DPI alert main components](pics/dpi-alerting-architecture.svg)
<br/><br/>
<h2><b>7. Proof of concept</b></h2>

To validate the architecture design choices we would need to develop and run a PoC.
It would be devided into 2 sub-PoCs:

- The first one validates the monitoring phase: From data colletion via kafka to alert posting to the other Kafka bus.
- The second one validates the notification phase: From alert message collection via kafka bus to delivery to fake email and sms servers.

We would have to set up a local environment (non cloud) for the PoCs. The production environment being in the cloud, would be more performant. So a number of metrics data less than the target (~1 billion) but still representative enough should be used.

In the first part, the system would be fed by historic or (fake) generated data that has a percentage of values that would trigger alerts.

The first PoC validates that the expected number of alerts is generated. While the second one validates that the expected number of notifications are sent/silenced with a given configuration.